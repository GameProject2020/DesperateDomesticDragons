import axios from 'axios';

export function postLogin(username, password) {
  // eslint-disable-next-line no-unused-vars
  return new Promise((resolve, reject) => {
    axios
      .post('/api/token/', {
        username,
        password,
      })
      .then(result => {
        if (result.status === 200) {
          resolve({ status: 'success', data: result.data });
        } else {
          resolve({ status: 'failed', data: null });
        }
      })
      .catch(error => {
        resolve({ status: 'failed', data: error });
      });
  });
}

/**
 * Hakee kaikki asiasanat.
 * Tekee HTTP GET -requestin resurssiin /api/asiasana. Palauttaa taulukon objekteja.
 */
export function getAsiasanat() {
  return new Promise((resolve, reject) => {
    axios
      .get('/api/hakusana')
      .then(result => {
        result.status === 200
          ? resolve({ status: 'success', data: result.data })
          : resolve({ status: 'failure', data: null });
      })
      .catch(error => {
        reject({ status: 'error', data: error });
      });
  });
}

/*
export function getHeadword(id) {
  // eslint-disable-next-line no-unused-vars
  return new Promise((resolve, reject) => {
    axios
      .get(`/headword/${id}`)
      .then(result => {
        if (result.status === 200) {
          resolve({ status: 'success', data: result.data });
        } else {
          resolve('failed');
        }
      })
      .catch(error => {
        resolve({ status: 'failed', data: error });
      });
  });
}*/

export function getChoices() {
  // eslint-disable-next-line no-unused-vars
  return new Promise((resolve, reject) => {
    axios
      .get('/choices/')
      .then(result => {
        if (result.status === 200) {
          resolve({ status: 'success', data: result.data });
        } else {
          resolve('failed');
        }
      })
      .catch(error => {
        resolve({ status: 'failed', data: error });
      });
  });
}

export function haeSanaluokka(id) {
  // eslint-disable-next-line no-unused-vars
  return new Promise((resolve, reject) => {
    axios
      .get(`/wordclass/${id}`)
      .then(result => {
        if (result.status === 200) {
          resolve(result.data);
        } else {
          resolve('failed');
        }
      })
      .catch(error => {
        resolve({ status: 'failed', data: error });
      });
  });
}

export function postAsiasana(asiasana) {
  return new Promise((resolve, reject) => {
    axios
      .post('/api/hakusana', asiasana)
      .then(result => {
        result.status === 201
          ? resolve({ status: 'success' })
          : resolve({ status: 'failure' });
      })
      .catch(error => {
        reject({ status: 'error', data: error });
      });
  });
}

export function postKulttuurituote(kulttuurituote) {
  return new Promise((resolve, reject) => {
    axios
      .post('/api/kulttuuriteos', kulttuurituote)
      .then(result => {
        result.status === 201
          ? resolve({ status: 'success' })
          : resolve({ status: 'failure' });
      })
      .catch(error => {
        reject({ status: 'error', data: error });
      });
  });
}

export function postOrganisaatio(organisaatio) {
  return new Promise((resolve, reject) => {
    axios
      .post('/api/organisaatio', organisaatio)
      .then(result => {
        result.status === 201
          ? resolve({ status: 'success' })
          : resolve({ status: 'failure' });
      })
      .catch(error => {
        reject({ status: 'error', data: error });
      });
  });
}