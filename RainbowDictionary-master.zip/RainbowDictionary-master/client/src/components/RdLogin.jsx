import React, { useContext, useState } from 'react';
import styled from 'styled-components';
import { Container, Button, Form, Grid } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import UserContext from '../context/userContext';
import RdHeader from './RdHeader';
import RdMenu from './RdMenu';
import { postLogin } from '../api/api';

const MainStructure = ({ className }) => {
  const history = useHistory();
  // eslint-disable-next-line no-unused-vars
  const [token, setToken] = useContext(UserContext);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState(undefined);

  const login = () => {
    postLogin(username, password).then(result => {
      if (result.status === 'success') {
        setToken(result.data.access);
        setUsername('');
        setPassword('');
        history.push('/');
      } else {
        setMessage('Tarkista käyttäjätunnus ja salasana.');
      }
    });
  };

  return (
    <div className={className}>
      <Container>
        <RdHeader />
        <RdMenu history={history} activeItem="kirjautuminen" />
        <div className="loginheader">
          <p>Kirjautuminen admin-käyttäjänä</p>
          {message ? <p style={{ color: 'red' }}>{message}</p> : null}
        </div>
        <Grid centered>
          <Grid.Column mobile={16} tablet={8} computer={5}>
            <Form onSubmit={login}>
              <Form.Input
                label="Käyttäjätunnus"
                placeholder="Käyttäjätunnus"
                value={username}
                // eslint-disable-next-line no-unused-vars
                onChange={(e, { name, value }) => setUsername(value)}
              />
              <Form.Input
                label="Salasana"
                type="password"
                placeholder="Salasana"
                value={password}
                // eslint-disable-next-line no-unused-vars
                onChange={(e, { name, value }) => setPassword(value)}
              />
              <Button type="submit">Kirjaudu</Button>
            </Form>
          </Grid.Column>
        </Grid>
      </Container>
    </div>
  );
};

const RdLogin = styled(MainStructure)`
  width: 100%;
  height: 100vh;
  text-align: center;
  background-color: ${({ theme }) => theme.palette.primary.main};

  .loginheader {
    margin-top: 3rem;
    margin-bottom: 3rem;
  }
`;

MainStructure.propTypes = {
  className: PropTypes.string,
};

export default RdLogin;
