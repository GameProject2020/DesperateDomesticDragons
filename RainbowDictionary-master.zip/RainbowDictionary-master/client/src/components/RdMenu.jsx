import React, { useContext } from 'react';
import styled from 'styled-components';
import { Menu, Icon, Button, Dropdown } from 'semantic-ui-react';
import PropTypes from 'prop-types';

import UserContext from '../context/userContext';

const MainStructure = ({ className, activeItem, history }) => {
  const [token, setToken] = useContext(UserContext);

  const options = [
    {
      key: 'logout',
      icon: 'sign out',
      text: 'Kirjaudu ulos',
      value: 'logout',
      href: '/',
      onClick: () => setToken(undefined),
    },
  ];

  return (
    <div className={className}>
      <Menu stackable size="large" className="rdmenu">
        <Menu.Item
          name="johdanto"
          active={activeItem === 'johdanto'}
          onClick={() => history.push('/')}
        />
        <Menu.Item
          name="sanakirja"
          active={activeItem === 'sanakirja'}
          onClick={() => history.push('/sanakirja')}
        />
        <Menu.Item
          name="sanalomake"
          active={activeItem === 'sanalomake'}
          onClick={() => history.push('/sanalomake')}
        />
        
        <Menu.Menu position="right">
          {token ? (
            <Menu.Item name={token} active={activeItem === 'käyttäjä'}>
              <Button.Group>
                <Icon name="user" />
                <Dropdown
                  icon="user"
                  floating
                  options={options}
                  trigger={<React.Fragment />}
                />
              </Button.Group>
            </Menu.Item>
          ) : (
            <Menu.Item
              active={activeItem === 'kirjautuminen'}
              onClick={() => history.push('/kirjautuminen')}
            >
              <Icon name="sign in" />
            </Menu.Item>
          )}
        </Menu.Menu>
      </Menu>
    </div>
  );
};

const RdMenu = styled(MainStructure)`
  margin-top: 1rem;

  .rdmenu {
    background: red;
    background-color: ${({ theme }) => theme.palette.primary.lighter};
  }

  .ui.menu .item {
    color: ${({ theme }) => theme.palette.primary.darker};
  }
`;

MainStructure.propTypes = {
  activeItem: PropTypes.string,
  history: PropTypes.object,
  className: PropTypes.string,
};

export default RdMenu;
