import React from 'react';
import { Table } from 'semantic-ui-react';

const AsiasananIlmentyma = ({ ilmentyma }) => (
  <>
    <Table.Row>
      <Table.Cell><b>Ilmentymä</b></Table.Cell>
    </Table.Row>
    <Table.Row>
      <Table.Cell>
        <ul>
          <li><b>SELITE:</b> { ilmentyma.selite }</li>
          <li><b>KÄYTTÖALA:</b> { ilmentyma.kayttoala }</li>
          <li><b>TYYLI:</b> { ilmentyma.tyyli } </li>
          <li><b>LEHTIOSIO:</b> { ilmentyma.hs_osio }</li>
          <li><b>PÄIVÄYS:</b> { ilmentyma.hspvm }</li>
          <li><b>LAUSE:</b> { ilmentyma.lause }</li>
        </ul>      
      </Table.Cell>
    </Table.Row>
  </>
);

export default AsiasananIlmentyma;
