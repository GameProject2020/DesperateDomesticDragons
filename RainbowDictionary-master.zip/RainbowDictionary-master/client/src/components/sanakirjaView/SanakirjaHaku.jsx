import React from 'react';
import { Icon, Input } from 'semantic-ui-react';
import PropTypes from 'prop-types';

import './SanakirjaHaku.css'

const SanakirjaHaku = ({ className }) => {
  return (
    <div className={className} style={{ textAlign: 'left' }}>
      <Input
        icon={<Icon name="search" inverted circular link />}
        placeholder="ABC..."
        size="large"
      />
    </div>
  );
};

SanakirjaHaku.propTypes = {
  className: PropTypes.string,
};

export default SanakirjaHaku;
