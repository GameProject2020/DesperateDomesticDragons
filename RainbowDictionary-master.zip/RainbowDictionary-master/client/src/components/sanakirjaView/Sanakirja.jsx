import React from 'react';
import styled from 'styled-components';
import { Container } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import RdHeader from '../RdHeader';
import RdMenu from '../RdMenu';
import SanakirjaNaytto from './SanakirjaNaytto';
// import { Loader } from 'semantic-ui-react';

const SanakirjaPlain = ({ className }) => {
  const history = useHistory();
  return (
    <div className={className}>
      <Container>
        <RdHeader />
        <RdMenu history={history} activeItem="sanakirja" />
        <SanakirjaNaytto />
        {/*
        <Loader active inline className="slow red" />
        <Loader active inline className="fast green" />
        */}
      </Container>
    </div>
  );
};

const Sanakirja = styled(SanakirjaPlain)`
  width: 100%;
  height: 100vh;
  background-color: ${({ theme }) => theme.palette.primary.main};

  h1.ui.header {
    text-align: center;
  }

  .input {
    margin-top: 4rem;
  }

  .ui.icon.input > i.icon {
    background: #9b59b6;
  }
`;

Sanakirja.propTypes = {
  className: PropTypes.string,
};

export default Sanakirja;
