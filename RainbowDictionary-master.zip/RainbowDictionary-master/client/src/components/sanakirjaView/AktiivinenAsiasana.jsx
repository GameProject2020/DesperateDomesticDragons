import React from 'react';
import { Table, Header, Segment } from 'semantic-ui-react';
import RdIlmentyma from './AsiasananIlmentyma';

const AktiivinenAsiasana = ({ aktiivinenAsiasana }) => (
  <div className="">
    <Header as="h3" style={{ textAlign: 'left', marginBottom: '1rem' }}>
      {aktiivinenAsiasana.asiasana}
    </Header>
    <Segment basic>
      <Table basic style={{ width: '85%'}}>
          <Table.Body>
            <Table.Row>
              <Table.Cell><b>SANALUOKKA</b></Table.Cell>
              <Table.Cell>{aktiivinenAsiasana.sanaluokka}</Table.Cell>
            </Table.Row>
            {aktiivinenAsiasana.ilmentymat.map(ilmentyma => 
                <RdIlmentyma key={ilmentyma.id} ilmentyma={ilmentyma} />
              )}
          </Table.Body>      
      </Table>
    </Segment>
  </div>
)

export default AktiivinenAsiasana;
