import React, { useEffect, useState } from 'react';
import { Button, Header, Menu, Segment, Sidebar } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { getAsiasanat } from '../../api/api';

import SanakirjaHaku from './SanakirjaHaku'
import AktiivinenAsiasana from './AktiivinenAsiasana'

import './SanakirjaNaytto.css';

const SanakirjaNaytto = ({ className }) => {
  // state hookit joilla hallitaan komponentin tilaa
  // eslint-disable-next-line no-unused-vars
  const [asiasanat, setAsiasanat] = useState([]);
  const [aktiivinenAsiasana, setAktiivinenAsiasana] = useState(undefined);
  const [hakuSanat, setHakusanat] = useState([]);
  const [hakuAktiivinen, setHakuAktiivinen] = useState(false);

  // Effect hook hakee asiasanat valmiiksi kutsumalla api.js haeAsiasanat-funktiota
  // ennen komponentin renderöintiä
  useEffect(() => {
    // haeAsiasanat-funktio palauttaa Promisen
    getAsiasanat().then(result => {
      // Tarkistetaan että haku onnistui
      if (result.status === 'success') {
        // muutetaa komponentin tilaa asettamalla asiasanat tilataulukkoon arvoksi
        // haetut asiasanat (Promisen tulosobjektin result muuttujassa data)
        setAsiasanat(result.data.sanat);
      } else {
        // Haku ei onnistunut, kirjoitetaan virheviesti konsoliin
        console.log('Failed to get information.');
        // TODO: Miten ilmoitetaan virheestä käyttäjälle???
      }
    });
  }, []);

  const kasitteleHaku = (e) => {
    e.preventDefault();
  }

  // Varsinainen RdSidebar komponentti vaikka nimi onkin MainStructure ennenkuin
  // tyyliosuus on lisätty
  return (
    <div className={className}>
      <SanakirjaHaku onClick={kasitteleHaku} />
      <Sidebar.Pushable as={Segment} className="rdSidebar">
        <Sidebar
          as={Menu}
          animation="push"
          direction="left"
          icon="labeled"
          vertical
          visible={true}
          width="thin"
        >
          {asiasanat.map((item, index) => (
            <Menu.Item
              key={item.id}
              as="a"
              onClick={() => setAktiivinenAsiasana(item)}
            >
              {`${item.asiasana}`}
            </Menu.Item>
          ))}
        </Sidebar>
        <Sidebar.Pusher>
          <Segment basic>
            {aktiivinenAsiasana ? <AktiivinenAsiasana aktiivinenAsiasana={aktiivinenAsiasana} /> : null}
          </Segment>
        </Sidebar.Pusher>
      </Sidebar.Pushable>
    </div>
  );
};

SanakirjaNaytto.propTypes = {
  className: PropTypes.string,
};

export default SanakirjaNaytto;
