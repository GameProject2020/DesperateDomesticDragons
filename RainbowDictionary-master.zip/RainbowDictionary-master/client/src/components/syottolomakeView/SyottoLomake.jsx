import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { Container, Button, Form, Grid } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import RdHeader from '../RdHeader';
import RdMenu from '../RdMenu';

import Sanalomake from './Sanalomake'
import Kulttuurituotelomake from './Kulttuurituotelomake'
import Organisaatiolomake from './Organisaatiolomake'

const SyottoLomakeRaw = ({ className }) => {
  const history = useHistory();

  const [activeFormId, setActiveFormId] = useState('form1');
  const handleActiveFormChange = v => setActiveFormId(v);

  const FormSelectButton = ({ formId, children }) => (
    <button onClick={() => handleActiveFormChange(formId)}>{children}</button>
  );

  return (
    <div className={className}>
      <Container>
        <RdHeader />
        <RdMenu history={history} activeItem="sanalomake" />
        <div className="infoheader">
          <Grid centered>
            <FormSelectButton
              formId={'form1'}
              centered
              input
              type="reset"
              value="reset"
            >
              Lisää sana
            </FormSelectButton>
            <FormSelectButton
              formId={'form2'}
              centered
              input
              type="reset"
              value="reset"
            >
              Lisää kulttuurituote
            </FormSelectButton>
            <FormSelectButton
              formId={'form3'}
              centered
              input
              type="reset"
              value="reset"
            >
              Lisää organisaatio
            </FormSelectButton>
          </Grid>
          <br></br>
          <br></br>
          <br></br>
          <Grid centered>
            <Grid.Column mobile={16} tablet={10} computer={10}>
              {activeFormId === 'form1' && (
                <Sanalomake />
              )}
              {activeFormId === 'form2' && (
                <Kulttuurituotelomake />
              )}

              {activeFormId === 'form3' && (
                <Organisaatiolomake />
              )}
            </Grid.Column>
          </Grid>
        </div>
      </Container>
    </div>
  );
};

const SyottoLomake = styled(SyottoLomakeRaw)`
  width: 100%;
  height: 100vh;
  background-color: ${({ theme }) => theme.palette.primary.main};

  .infoheader {
    margin-top: 3rem;
    margin-bottom: 3rem;
  }
`;

SyottoLomakeRaw.propTypes = {
  className: PropTypes.string,
};

export default SyottoLomake;