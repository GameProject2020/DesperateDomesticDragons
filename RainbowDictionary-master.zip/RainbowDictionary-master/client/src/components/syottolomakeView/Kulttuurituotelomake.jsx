import React, { useState } from 'react'
import { Button, Form } from 'semantic-ui-react'

import { postKulttuurituote } from '../../api/api'

const Kulttuurituotelomake = (props) => {


  const [kulttuurituoteTila, setKulttuurituoteTila] = useState({
    tekija_etunimi: '',
    tekija_sukunimi: '',
    tekija_ammatti: '',
    tekija_paikkakunta: '',
    tekija_maa: '',
    teos_nimi: '',
    teos_lajityyppi: '',
    teos_asiasana: '',
    teos_tapahtumapaikkakunta: '',
    teos_tapahtumamaa: '',
  })

  const muutaKulttuurituotteenTilaa = (e) => {
    const { name, value } = e.target
    setKulttuurituoteTila(prev => ({
      ...prev,
      [name]: value,
    }))
  }

  const tarkistaKulttuurituoteLomake = () => {
    //let lehtiosiotarkistus = lehtiosio.value;
    if (
      kulttuurituoteTila['tekija_etunimi'].length > 0 &&
      kulttuurituoteTila['tekija_sukunimi'].length > 0 &&
      kulttuurituoteTila['tekija_ammatti'].length > 0 &&
      kulttuurituoteTila['tekija_paikkakunta'].length > 0 &&
      kulttuurituoteTila['tekija_maa'].length > 0 &&
      kulttuurituoteTila['teos_nimi'].length > 0 &&
      kulttuurituoteTila['teos_lajityyppi'].length > 0 &&
      kulttuurituoteTila['teos_asiasana'].length > 0 &&
      kulttuurituoteTila['teos_tapahtumapaikkakunta'].length > 0 &&
      kulttuurituoteTila['teos_tapahtumamaa'].length > 0
    ) {
      console.log('Kaikki kentät täytetty');

      var luoFormiobjekti2 = {
        etunimi: kulttuurituoteTila['tekija_etunimi'],
        sukunimi: kulttuurituoteTila['tekija_sukunimi'],
        henkilo_maa: kulttuurituoteTila['tekija_maa'],
        henkilo_paikkakunta: kulttuurituoteTila['tekija_paikkakunta'],
        ammattinimike: kulttuurituoteTila['tekija_ammatti'],
        lajityyppi: kulttuurituoteTila['teos_lajityyppi'],
        nimi: kulttuurituoteTila['teos_nimi'],
        kuvaus: kulttuurituoteTila['teos_asiasana'],
        teos_paikkakunta: kulttuurituoteTila['teos_tapahtumapaikkakunta'],
        teos_maa: kulttuurituoteTila['teos_tapahtumamaa']
      };
      console.log(luoFormiobjekti2);
      postKulttuurituote(luoFormiobjekti2);
      tyhjennaKulttuurituoteLomake()
    } else {
      console.log('Kenttiä puuttuu');
    }
  };

  const tyhjennaKulttuurituoteLomake = () => {
    setKulttuurituoteTila({
      tekija_etunimi: '', tekija_sukunimi: '', tekija_ammatti: '', tekija_paikkakunta: '',
      tekija_maa: '', teos_nimi: '', teos_lajityyppi: '', teos_asiasana: '', 
      teos_tapahtumapaikkakunta: '', teos_tapahtumamaa: '',      
    })
  }

  return (
    <Form
      name="Kulttuurituotelomake"
      method="post"
    >
      <font size="6" color="purple">
        Kulttuurituotelomake
      </font>
      <br></br>
      <br></br>
      <Form.Group widths="equal">
        <Form.Input
          label="Tekijän etunimi"
          name="tekija_etunimi"
          value={kulttuurituoteTila['tekija_etunimi']}
          onChange={muutaKulttuurituotteenTilaa}
        />
        <Form.Input
          label="Tekijän sukunimi"
          placeholder=""
          name="tekija_sukunimi"
          value={kulttuurituoteTila['tekija_sukunimi']}
          onChange={muutaKulttuurituotteenTilaa}
        />
      </Form.Group>
      <Form.Group>
        <Form.Input
          label="Tekijän ammatti"
          name="tekija_ammatti"
          value={kulttuurituoteTila['tekija_ammatti']}
          onChange={muutaKulttuurituotteenTilaa}
        />
      </Form.Group>
      <Form.Group widths="equal">
        <Form.Input
          label="Tekijän paikkakunta"
          placeholder=""
          name="tekija_paikkakunta"
          value={kulttuurituoteTila['tekija_paikkakunta']}
          onChange={muutaKulttuurituotteenTilaa}
        />
        <Form.Input
          label="Tekijän maa"
          placeholder="Suomi"
          name="tekija_maa"
          value={kulttuurituoteTila['tekija_maa']}
          onChange={muutaKulttuurituotteenTilaa}
        />
      </Form.Group>
      <Form.Group widths="equal">
        <Form.Input
          label="Teoksen nimi"
          name="teos_nimi"
          value={kulttuurituoteTila['teos_nimi']}
          onChange={muutaKulttuurituotteenTilaa}
        />
        <Form.Input
          label="Teoksen lajityyppi"
          placeholder="Kirja/musiikki/taideteos jne."
          name="teos_lajityyppi"
          value={kulttuurituoteTila['teos_lajityyppi']}
          onChange={muutaKulttuurituotteenTilaa}
        />
      </Form.Group>
      <Form.Group>
        <Form.Input 
          label="Teoksen asiasana"
          name="teos_asiasana"
          value={kulttuurituoteTila['teos_asiasana']}
          onChange={muutaKulttuurituotteenTilaa}
        />
      </Form.Group>
      <Form.Group>
        <Form.Input
          label="Teoksen paikkakunta"
          name="teos_tapahtumapaikkakunta"
          value={kulttuurituoteTila['teos_tapahtumapaikkakunta']}
          onChange={muutaKulttuurituotteenTilaa}
        />
        <Form.Input
          label="Teoksen tapahtumamaa"
          name="teos_tapahtumamaa"
          value={kulttuurituoteTila['teos_tapahtumamaa']}
          onChange={muutaKulttuurituotteenTilaa}
        />
      </Form.Group>
      <Button
        //type="submit"
        //(e, v) => handleThis(e, v)
        onClick={tarkistaKulttuurituoteLomake}
        //disabled={tarkistaLomake}
      >
        Tallenna
      </Button>

      <Button onClick={tyhjennaKulttuurituoteLomake} >
        Tyhjennä
      </Button>
    </Form>
  )
}

export default Kulttuurituotelomake