import React, {useState} from 'react'
import { Button, Form } from 'semantic-ui-react'

import { postOrganisaatio } from '../../api/api';

const Organisaatiolomake = () => {
  
  const [organisaatioTila, setOrganisaatioTila] = useState({
    nimi: '',
    asiasana: '',
    tapahtuma_nimi: '',
    tapahtuma_luonne: '',
    paikkakunta: '',
    maa: '',
    vuosi: '',
  })

  // organisaation tilan muuttaminen
  const muutaOrganisaationTila = e => {
    const { name, value } = e.target
    setOrganisaatioTila(prev => ({
      ...prev,
      [name]: value,
    }))
  }

  const tyhjennaOrganisaatioLomake = () => {
    setOrganisaatioTila({
      nimi: '', asiasana: '', tapahtuma_nimi: '', tapahtuma_luonne: '',
      paikkakunta: '', maa: '', vuosi: '',  
    })
  }

  const tarkistaOrganisaatiolomake = () => {
    //let lehtiosiotarkistus = lehtiosio.value;
    if (
      organisaatioTila['nimi'].length > 0 &&
      organisaatioTila['asiasana'].length > 0 &&
      organisaatioTila['tapahtuma_nimi'].length > 0 &&
      organisaatioTila['tapahtuma_luonne'].length > 0 &&
      organisaatioTila['paikkakunta'].length > 0 &&
      organisaatioTila['maa'].length > 0 &&
      organisaatioTila['vuosi'].length > 0
    ) {
      console.log('Kaikki kentät täytetty');
      /*
      tapahtuma_nimi, org_nimi, maa, paikkakunta, luonne, vuosi, kuvaus
      */
      var luoFormiobjekti = {
        org_nimi: organisaatioTila['nimi'],
        kuvaus: organisaatioTila['asiasana'],
        tapahtuma_nimi: organisaatioTila['tapahtuma_nimi'],
        luonne: organisaatioTila['tapahtuma_luonne'],
        maa: organisaatioTila['maa'],
        paikkakunta: organisaatioTila['paikkakunta'],
        vuosi: organisaatioTila['vuosi'],
      };
      console.log(luoFormiobjekti);
      postOrganisaatio(luoFormiobjekti);
    } else {
      console.log('Kenttiä puuttuu');
    }
  };


  return (
    <Form
      name="Organisaatiolomake"
      method="post"
    >
      <font size="6" color="purple">
        Organisaatiolomake
      </font>
      <br></br>
      <br></br>
      <Form.Group widths="equal">
        <Form.Input
          label="Organisaation nimi"
          name="nimi"
          value={organisaatioTila['nimi']}
          onChange={muutaOrganisaationTila}
        />
        <Form.Input
          label="Asiasana"
          name="asiasana"
          value={organisaatioTila['asiasana']}
          onChange={muutaOrganisaationTila}
        />
      </Form.Group>
      <Form.Group>
        <Form.Input 
          label="Tapahtuman nimi"
          name="tapahtuma_nimi"
          value={organisaatioTila['tapahtuma_nimi']}
          onChange={muutaOrganisaationTila}
        />
        <Form.Input 
          label="Tapahtuman luonne"
          name="tapahtuma_luonne"
          value={organisaatioTila['tapahtuma_luonne']}
          onChange={muutaOrganisaationTila}
        />
      </Form.Group>
      <Form.Group widths="equal">
        <Form.Input
          label="Paikkakunta"
          name="paikkakunta"
          value={organisaatioTila['paikkakunta']}
          onChange={muutaOrganisaationTila}
        />
        <Form.Input
          label="Maa"
          placeholder="Suomi"
          name="maa"
          value={organisaatioTila['maa']}
          onChange={muutaOrganisaationTila}
        />
      </Form.Group>
      <Form.Group>
        <Form.Input 
          label="Uutisen ilmestymisvuosi"
          name="vuosi"
          value={organisaatioTila['vuosi']}
          onChange={muutaOrganisaationTila}
        />
      </Form.Group>

      <Button
        onClick={tarkistaOrganisaatiolomake}
      >
        Tallenna
      </Button>

      <Button onClick={tyhjennaOrganisaatioLomake}>
        Tyhjennä
      </Button>
    </Form>
  )
}

export default Organisaatiolomake