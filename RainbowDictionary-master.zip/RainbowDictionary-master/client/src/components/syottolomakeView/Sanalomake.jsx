import React, { useState, useEffect } from 'react'
import { Button, Form } from 'semantic-ui-react'
import { postAsiasana } from '../../api/api';

const Sanalomake = () => {
  // HAKUSANOIHIN LIITTYVÄ TILA
  const [formValidi, setFormValidi] = useState(false)
  const [hakusanaTila, setHakusanaTila] = useState({
    hs_osio: '',
    paivays: '',
    asiasana: '',
    hakusana: '',
    selite: '',
    sanaluokka: '',
    tyyli: '',
    kayttoala: '',
    lause: '',
  })

  // SUBMIT-nappi aktiivinen vai ei? Alussa pois päältä.
  const [btnDisable, setBtnDisable] = useState(true)

  // hakusanan tilan muuttaminen
  const muutaHakusananTilaa = (e) => {
    const { name, value } = e.target
    setHakusanaTila(prev => ({
      ...prev,
      [name]: value,
    }))
  }

  const tyhjennaSanaLomake = () => {
    setHakusanaTila({
      hs_osio: '', paivays: '', hakusana: '', asiasana: '', selite: '', sanaluokka: '',
      tyyli: '', kayttoala: '', lause: '',      
    })
  }

  //Tarkistetaan formi, että siinä on tarvittavat tiedot sanan tallennusta varten
  const tarkistaSanaLomake = () => {
    //let lehtiosiotarkistus = lehtiosio.value;
    if (
      hakusanaTila['hs_osio'].length > 0 &&
      hakusanaTila['paivays'].length > 0 &&
      hakusanaTila['asiasana'].length > 0 &&
      hakusanaTila['hakusana'].length > 0 &&
      hakusanaTila['selite'].length > 0 &&
      hakusanaTila['sanaluokka'].length > 0 &&
      hakusanaTila['tyyli'].length > 0 &&
      hakusanaTila['kayttoala'].length > 0 &&
      hakusanaTila['lause'].length > 0
    ) {
      console.log('Kaikki kentät täytetty');
      var luoFormiobjekti = {
        hs_osio: hakusanaTila['hs_osio'],
        paivays: hakusanaTila['paivays'],
        kuvaus: hakusanaTila['asiasana'],
        sana: hakusanaTila['hakusana'],
        selite: hakusanaTila['selite'],
        sanaluokka: hakusanaTila['sanaluokka'],
        tyyli: hakusanaTila['tyyli'],
        kayttoala: hakusanaTila['kayttoala'],
        lause: hakusanaTila['lause'],
      };
      postAsiasana(luoFormiobjekti).then(obj => console.log(obj))
      tyhjennaSanaLomake()
    } else {
      console.log('Kenttiä puuttuu');
    }
  };

  return (
    <Form
      name="Sanalomake"
      method="post"
    >
    <font size="6" color="purple">
      Sanalomake
    </font>
    <br></br>
    <br></br>
    <Form.Group widths="equal">
      <Form.Input
        label="Päiväys"
        name="paivays"
        value={hakusanaTila['paivays']}
        placeholder="HS19"
        onChange={muutaHakusananTilaa}
      />
      <Form.Input
        label="Lehden osio"
        name="hs_osio"
        value={hakusanaTila['hs_osio']}
        onChange={muutaHakusananTilaa}
      />
    </Form.Group>
    <Form.Group widths="equal">
      <Form.Input
        label="Hakusana"
        name="hakusana"
        value={hakusanaTila['hakusana']}
        onChange={muutaHakusananTilaa}
      />
      <Form.Input
        label="Hakusanan selite"
        placeholder="Selite"
        name="selite"
        value={hakusanaTila['selite']}
        onChange={muutaHakusananTilaa}
      />
    </Form.Group>
    <Form.Group widths="equal">
      <Form.Input
        label="Asiasana"
        name="asiasana"
        value={hakusanaTila['asiasana']}
        onChange={muutaHakusananTilaa}
      />
    </Form.Group>
    <Form.Group widths="equal">
      <Form.Input
        label="Sanaluokka"
        name="sanaluokka"
        value={hakusanaTila['sanaluokka']}
        onChange={muutaHakusananTilaa}
      />
      <Form.Input
        label="Tyyli"
        name="tyyli"
        value={hakusanaTila['tyyli']}
        onChange={muutaHakusananTilaa}
      />
      <Form.Input
        label="Käyttöala"
        name="kayttoala"
        value={hakusanaTila['kayttoala']}
        onChange={muutaHakusananTilaa}
      />
    </Form.Group>

    <Form.TextArea
      label="Lause"
      name="lause"
      value={hakusanaTila['lause']}
      onChange={muutaHakusananTilaa}
    />

    <Button
      onClick={tarkistaSanaLomake}
    >
      Tallenna
    </Button>

    <Button
      onClick={tyhjennaSanaLomake}
    >
      Tyhjennä
    </Button>
  </Form>
  )
}

export default Sanalomake