import React from 'react';
import styled from 'styled-components';
import { Container, Button, Form, Grid } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import RdHeader from './RdHeader';
import RdMenu from './RdMenu';

const MainStructure = ({ className }) => {
  const history = useHistory();
  return (
    <div className={className}>
      <Container>
        <RdHeader />
        <RdMenu history={history} activeItem="lomakkeet" />
        <div className="infoheader">
          <Grid centered>
            <Grid.Column mobile={16} tablet={8} computer={5}>
              <Form>
                <Form.Dropdown
                  label="Asiasana"
                  search
                  selection
                  options={null}
                />
                <Form.Dropdown
                  label="Organisaatio"
                  search
                  selection
                  options={null}
                />
                <Form.Dropdown
                  label="Organisaation tapahtuma"
                  search
                  selection
                  options={null}
                />
                <Button type="submit">Tallenna</Button>
                <Button type="submit">Tyhjennä</Button>
              </Form>
            </Grid.Column>
          </Grid>
        </div>
      </Container>
    </div>
  );
};

const RdPersonForm = styled(MainStructure)`
  width: 100%;
  height: 100vh;
  background-color: ${({ theme }) => theme.palette.primary.main};

  .infoheader {
    margin-top: 3rem;
    margin-bottom: 3rem;
  }
`;

MainStructure.propTypes = {
  className: PropTypes.string,
};

export default RdPersonForm;
