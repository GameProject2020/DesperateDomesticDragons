import React from 'react';
import styled from 'styled-components';
import { Container } from 'semantic-ui-react';
import PropTypes from 'prop-types';
import { useHistory } from 'react-router-dom';
import RdHeader from './RdHeader';
import RdMenu from './RdMenu';

const MainStructure = ({ className }) => {
  const history = useHistory();
  return (
    <div className={className}>
      <Container>
        <RdHeader />
        <RdMenu history={history} activeItem="johdanto" />
        <div className="infoheader">
          <h3>JOHDANTO – SATEENKAARIHISTORIAN HAKUSANAKIRJA</h3>
        </div>
        <div class="ui padded segment">
          <p>
          Tässä johdannossa kerrotaan siitä, mitä kannattaa huomioida, jos haluaa ymmärtää menneisyydessä käytyä 
          kirjoittelua nykypäivästä käsin. Siinä annetaan myös käyttöohjeita ja kerrotaan, mihin ja miten voit
          käyttää Sateenkaarihistorian hakusanakirjaa. 
          </p>
          <div class="ui divider"></div>
          <p>
          Ihmiset ovat kaikkina aikoina ilmaisseet sukupuoltaan monin tavoin, etsineet intiimiä läheisyyttä 
          toisistaan ja harrastaneet seksuaalisia tekoja keskenään. Mutta se, mitä merkityksiä näille teoille
          on annettu, miten niihin on suhtauduttu, miten niistä on puhuttu ja mitä niistä on kirjoitettu, riippuu 
          ratkaisevasti kulloisestakin ajasta ja paikasta. Suomessa on tehty toistaiseksi vain vähän historiallista
          tutkimusta siitä, miten meillä on käsitelty sellaista sukupuolen moninaisuutta, joka ylittää yksiselitteisen
          nais–mies-jaon, tai sellaisia intiimejä suhteita, jotka poikkeavat heteroseksuaalisesta oletuksesta.<sup>1</sup>
          </p>
          <p>
          Tämän <i>Sateenkaarihistorian hakusanakirjan</i> tarkoituksena on auttaa niin tutkijoita kuin muitakin asiasta 
          kiinnostuneita lähestymään sukupuolen ja seksuaalisuuden moninaisuuden kysymyksiä sanomalehtikirjoittelun
          varassa. Hakusanakirjaan on kerätty Helsingin Sanomissa vuosina 1904–1940 julkaistuista teksteistä ilmaisuja,
          joilla on viitattu ilmiöihin, joista puhuessamme käyttäisimme nykyisin esimerkiksi sellaisia sanoja
          kuin muunsukupuolisuus, transsukupuolisuus tai intersukupuolisuus, tai sitten homous, lesbous tai
          biseksuaalisuus. 
          </p>
          <p>
          On tärkeää huomata, että näiden nykyisten käsitteiden syntyyn, käyttöön ja erityisesti niiden saamiin
          merkityksiin on vaikuttanut vahvasti vuonna 1894 rikollisiksi määriteltyjen homoseksuaalisten tekojen
          dekriminalisointi vuonna 1971 sekä vuonna 1981 toteutettu homoseksuaalisuuden sairausluokituksen 
          poistaminen. Lisäksi lesbo- ja homoliike on 1970-luvulta lähtien hyödyntänyt tavoitteittensa ajamisessa
          avoimuuteen kannustavaa identiteettipolitiikkaa, samoin kuin sukupuolten moninaisuuden yhdenvertaisuutta
          myöhemmin ajamaan ryhtynyt transyhteisökin. Tämä poliittinen liikehdintä on ratkaisevasti muuttanut 
          ymmärrystämme seksuaalisuuden ja sukupuolen moninaisuudesta, ja siten myös sanomalehtien kirjoittelua
          aiheesta. Esimerkiksi muunsukupuolisuudesta, transsukupuolisuudesta ja intersukupuolisuudesta käytävässä
          keskustelussa viitataan nykyisin usein ihmisoikeuksiin, mikä ei aiemmin olisi monille tullut mieleenkään. 
          </p>
          <p>
          Seksuaalisuuden moninaisuudesta 1900-luvun ensimmäisellä puoliskolla käytyä sanomalehtikirjoittelua
          sen sijaan väritti vielä vahvasti ”samaa sukupuolta olevan henkilön kanssa harjoitetun haureuden”
          rikollinen ja siksi tuomittavaksi leimattu luonne. Rikosuutisointi oli siksi tavallisimmin se konteksti,
          jossa homoseksuaalisia teemoja käsiteltiin julkisesti. Tuohon aikaan aihepiiriä koskeva sanastokin etsi
          vielä muotoaan, ja hankalaksi koetusta ilmiöstä puhuttiin kernaasti erilaisia kiertoilmauksia käyttäen.
          Näitä kiertoilmaisuja on siksi otettu mukaan myös sanakirjaan. Sukupuolen moninaisuudesta taas
          tavallisimmin vaiettiin lehdistössä. Jos asia nostettiin esille, sitä koskeva käsitteistö oli sangen horjuvaa
          ja nykypäivästä käsin arvioituna vähintäänkin monimerkityksellistä.   
          </p>
          <p>
          Ankarasta lainsäädännöstä huolimatta niin naisten kuin miestenkin rikostuomiot homoseksuaalisista
          teoista olivat ennen 1950-lukua kaiken kaikkiaan hyvin harvinaisia. Näin ollen sanomalehtien 
          uutisointi antaa meille vain kalpean kuvan siitä, millaista seksuaalisuudeltaan toisenlaisten
          ihmisten arkielämä on ollut. Rajoittunut uutisointi koskee myös sukupuolen moninaisuutta. 
          Muiden lähteiden nojalla tiedämme kuitenkin, että puhekielessä on käytetty monenlaisia ronskejakin 
          ilmaisuja, joilla vallitsevasta sukupuolen ja seksuaalisuuden normistosta poikkeaminen on kuitattu siihen sen 
          kummemmin muuten puuttumatta. Sanomalehtien välityksellä saamme kuitenkin tietoa siitä, miten yhteiskunnassa 
          on pyritty määrittelemään ja kontrolloimaan poikkeavuuksia. 
          </p>
          <div class="ui divider"></div>
          <p><sup>1</sup> Lisätietoja suomalaisesta sateenkaarihistoriasta voit kuitenkin löytää esimerkiksi näistä teoksista: XX</p>
          </div>

          <div class="ui padded segment">
          <p>
          <div class="ui medium header"><p><b>Käyttöohjeet sanakirjaan</b></p></div>
          <i>Sateenkaarihistorian hakusanakirja</i> tarjoaa monenlaisia mahdollisuuksia menneisyyteen sukeltamiseen:  
          </p>
          <p>
          <b>1) Sanakirja-alasivu</b><br></br>
          Hakusanalistan avulla voit tutkia aakkosjärjestyksessä niitä <b>sanoja ja 
          ilmauksia</b>, joita on käytetty sukupuolen ja seksuaalisuuden moninaisuudesta kirjoitettaessa. Huomaa, että 
          sanojen tallennus päättyy vuoteen 1940. Joidenkin mukaan otettujen sanojen käyttö on jatkunut senkin jälkeen, 
          kun taas toiset ilmaisut ovat sittemmin jääneet pois käytöstä, samalla kun sanomalehtien sivuille on 
          ilmestynyt uusia, tästä hakusanakirjasta puuttumaan jääviä ilmaisuja.   
          </p>
          <p>
          Mukaan otetuille hakusanoille on annettu selite, jonka muotoilemisessa on pyritty välttämään anakronismeja, 
          eli nykyajalle ominaisten ajattelumuotojen siirtämistä menneisyyteen. Asiasana puolestaan kertoo nykykäsittein 
          sen aihealueen, johon sanan käyttö läheisimmin viittaa. Sanan tyylilaji taas ilmaisee sen, onko sanalla haluttu 
          esimerkiksi sievistellä asiaa <i>(eufemismi)</i> tai haluttu alleviivata sen tuomittavuutta <i>(dysfemismi)</i>. Käyttöala 
          viittaa siihen elämänpiiriin, johon käytetty sana on lehdessä liitetty. Usein se on esimerkiksi <i>juridiikka; 
          rikostutkinta; oikeudenkäynti,</i> mutta se voi olla myös vaikkapa <i>kulttuuri</i> tai <i>urheilu</i>. 
          </p>
          <p>
          Sanojen ja ilmauksien käyttöyhteydestä antaa lisää viitteitä se sanomalehden osio, jossa esimerkkilause esiintyy. 
          Myös esimerkkilause itsessään tarkentaa sanan käytön piiriä ja merkityksiä. Koska homoseksuaaliset teot olivat 
          rikollisia kyseisenä aikana, useat sanakirjan esimerkkilauseista kertovat homoseksuaalisuudesta tällä tavoin 
          värittyneesti. Se tietysti kertoo enemmän tuolloin vallinneista asenteista kuin homoseksuaalisuudesta elettynä 
          kokemuksena tai homoseksuaaleista ihmisinä. Esimerkkilauseisiin tutustumalla voit seurata myös sitä, millaisiin 
          asioihin samoillakin käsitteillä on eri aikoina viitattu. 
          </p>
          <p>
          <b>Sanakirja-alasivun hakutoiminnot:</b>
          <br>
          </br>
          Hakukenttään voit kirjoittaa yksittäisiä hakusanoja, kirjainvalikon kautta etsiä kaikkia tietyllä kirjaimella alkavia 
          sanoja, tai voit vain selailla sivun vasemmassa reunassa näkyvää sanalistaa. Samaan aihepiiriin liittyviä sanoja 
          voit hakea hakuvalikosta asiasanan avulla. Voit asettaa haullesi aikarajauksen vuoden tarkkuudella. Voit vaihtaa 
          näytön näkymän näyttämään esimerkkilauseet joko ensimmäisen tai viimeisen tallennetun ilmentymän mukaisessa aikajärjestyksessä.
          </p>
          <p>
          <b>2) Kulttuurituotteita-alasivu</b><br></br> 
          Tällä sivulla voit selata niiden kirjojen, näytelmien, oopperoiden, elokuvien tai muiden <b><i>teosten</i></b> nimiä, 
          joiden sanomalehdessä on kerrottu käsittelevän tavalla tai toisella sukupuolen tai seksuaalisuuden moninaisuutta. Teoksen 
          nimen avulla voit etsiä sen käsiisi esimerkiksi kirjastosta, ja sanomalehtiuutisointiin paneutumalla voit puolestaan seurata 
          sitä, miten näitä aiheita on käsitelty teosten vastaanotossa eri aikoina. Se, että jotain etsimääsi teosta ei löydy listasta, 
          ei tietenkään tarkoita, etteikö siinä silti voisi esiintyä näitäkin teemoja. On hyvin mahdollista, että niitä ei ole 
          haluttu mainita sanomalehdessä. 
          </p>
          <p>
          Halutessasi voit vaihtaa listauksen koskemaan <i><b>kulttuurituotteiden tekijöitä.</b></i> Heidän nimensä voi johdattaa sinut 
          edelleen alkuperäisen uutisen ääreen tai elämäkertojen pariin. Huomaa, että vaikka kulttuurituotteen tekijä on 
          käsitellyt teoksissaan sukupuolen ja seksuaalisuuden moninaisuutta, se ei välttämättä merkitse sitä, että hän on 
          valinnut aiheen siksi, että se ollut hänelle omakohtainen – vaikka joskus näinkin voi olla. Mutta yhtä hyvin hän on 
          voinut käyttää aihetta tuotannossaan esimerkiksi kertoakseen jotain kuvittelemansa henkilön luonteesta tai asemasta yhteisössään.   
          </p>
          <p>
          <b><i>Paikkakunnan</i></b> mukaan tehdyn rajauksen avulla voit tutkia siitä, onko sanomalehtiuutisoinnin yhteydessä mainittu johonkin tiettyyn 
          maantieteelliseen paikkaan liitetty teos tai kulttuurituotteen tekijä. Jos kyllä, tämä voi tuottaa uutta tietoja erityisesti 
          paikallishistoriasta kiinnostuneille.    
          </p>
          <p>
          <b>Kulttuurituotteita-alasivun hakutoiminnot:</b>
          <br>
          </br>
          Tällä sivulla voit tehdä hakuja teoksen nimen, lajityypin tai asiasanan perusteella, mutta myös kohdistaa haun siihen paikkakuntaan ja maahan, 
          johon teos sijoittuu. Samoin voit tehdä hakuja teoksen tekijöiden nimen tai ammattinimikkeen perusteella, mutta myös tekijän tai teoksen 
          yhteydessä mainitun paikkakunnan ja maan perusteella. Huomaa, että alkuperäisessä uutisessa ei aina ole mainittu paikkakuntaa tai maata, 
          jolloin tieto puuttuu myös hakusanakirjasta.  
          </p>
          <p>
          <b>3) Organisaatiot-alasivu </b>  
          <br></br>
          Omalta välilehdeltään löytyvä lista <b><i>organisaatioista</i></b> on suunnattu erityisesti tutkijoille, jotka etsivät sukupuolen ja 
          seksuaalisuuden moninaisuutta käsitteleviä ensikäden lähteitä arkistoista. Heille organisaation nimen tietäminen on tärkeää, 
          koska se auttaa heitä löytämään sen arkiston, johon organisaation asiakirjat on tallennettu. 
          Tutkijoiden kannattaa kohdentaa omat hakunsa myös itse sanomalehteen löytääkseen sieltä kaipaamiaan tarkempia 
          lisätietoja koskien esimerkiksi uutisoinnin ajankohtaa. 
          </p>
          <p>
          <b>Organisaatiot-alasivun hakutoiminnot: </b>
          <br></br>
          Tällä sivulla voit tehdä hakuja paitsi organisaation nimen perusteella, myös sen paikkakunnan ja maan perusteella, joka on mainittu 
          toimijatahon yhteydessä. Huomaa, että alkuperäisessä uutisessa ei aina ole mainittu paikkakuntaa tai maata, jolloin tieto puuttuu myös hakusanakirjasta.
          </p>
          <p>
          <b>4) Omien hakujen tekeminen digitalisoiduista sanomalehdistä</b>
          <br>
          </br>
          Kansallisarkiston verkkoportaalin kautta voit tehdä hakusanakirjasta löytämiesi sanojen varassa omia hakujasi paitsi <i>Helsingin Sanomiin</i>, 
          myös muihin digitalisoituihin lehtiin ja lukea niistä löytämäsi uutiset kokonaisuudessaan. Paperisia sanomalehtiä voit puolestaan lukea joissakin kirjastoissa. 
          </p>
          <p>
          Hyödyntämällä <i>Helsingin Sanomien</i> tilaajilleen tarjoaman <a target="_blank" rel="noopener noreferrer" href="https://www.hs.fi/aikakone/" title="hs.fi/aikakone">Aikakoneen</a> hakumahdollisuuksia pääset halutessasi tutustumaan
          myös vuoden 1940 jälkeisen ajan uutisointiin ja kielenkäyttöön. 
          </p>
        </div>
      </Container>
    </div>
  );
};

const RdInfo = styled(MainStructure)`
  width: 100%;
  height: 100vh;
  background-color: ${({ theme }) => theme.palette.primary.main};

  .infoheader {
    margin-top: 3rem;
    margin-bottom: 3rem;
    color: ${({ theme }) => theme.palette.primary.dark};
  }
  .header{
    color: ${({ theme }) => theme.palette.primary.dark};
  }
  .ui.segment {
    text-align: left;
    margin-bottom: 3rem;
  }
  .ui.medium.header {
    margin-top: 0.5rem;
  }
`;

MainStructure.propTypes = {
  className: PropTypes.string,
};

export default RdInfo;
