import React, { useState } from 'react';
import 'fomantic-ui-css/semantic.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import WebFont from 'webfontloader';
import { ThemeProvider } from 'styled-components';

import UserContext from './context/userContext';
import Sanakirja from './components/sanakirjaView/Sanakirja';
import RdInfo from './components/RdInfo';
import RdLogin from './components/RdLogin';
import SyottoLomake from './components/syottolomakeView/SyottoLomake';
import RdCultureForm from './components/RdCultureForm';
import RdOrganizationForm from './components/RdOrganizationForm';
import GlobalStyles from './styles/GlobalStyles';
import theme from './styles/theme';
import * as routes from './constants/routes';

WebFont.load({
  google: {
    families: ['Vollkorn:700', 'Open Sans:300,400,600,800'],
  },
});

const App = function AppContent() {
  const [token, setToken] = useState(undefined);

  return (
    <ThemeProvider theme={theme}>
      <>
        <GlobalStyles />
        <UserContext.Provider value={[token, setToken]}>
          <Router>
            <Switch>
              <Route exact path={routes.ROOT} component={RdInfo} />
              <Route path={routes.DICTIONARY} component={Sanakirja} />
              <Route path={routes.LOGIN} component={RdLogin} />
              <Route path={routes.WORDFORM} component={SyottoLomake} />
            </Switch>
          </Router>
        </UserContext.Provider>
      </>
    </ThemeProvider>
  );
};

export default App;
