export const ROOT = '/';
export const DICTIONARY = `${ROOT}sanakirja`;
export const LOGIN = `${ROOT}kirjautuminen`;
export const WORDFORM = `${ROOT}sanalomake`;
export const CULTUREFORM = `${ROOT}kulttuurilomake`;
export const ORGANIZATIONFORM = `${ROOT}organisaatiolomake`;
export const SUB_ROUTE = `${ROOT}other-route-goes-here`;
