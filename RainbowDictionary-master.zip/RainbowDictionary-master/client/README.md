# React Boilerplate

React, AirBnB ESLint, Prettier

See `package.json` for `npm` scripts.

## TODO

- Create proper README
- Add gh-pages publishing
