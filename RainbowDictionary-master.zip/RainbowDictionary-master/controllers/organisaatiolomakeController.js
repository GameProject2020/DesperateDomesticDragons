//haetaan tietokantayhteys config.js:stä
const connection = require('../config.js');

'use strict';

exports.returnOrgNimi = function (req, res, next) {
  console.log("Bing @ the returnOrgNimi controller")
  connection.query('SELECT DISTINCT nimi FROM organisaatio', (error, results) => {
    if (error) {
      next(error)  
    } else {
      let tiedot = [];
      let nimet = {"org_nimi": []};
      for (let i in results.rows) {
        nimet.org_nimi.push(results.rows[i].nimi)
        if (results.rows.length - i === 1) {
          tiedot.push(nimet)
          req.tieto = tiedot
          next()
        }
      }
      if (results.rows.length === 0) {
        req.tieto = tiedot
        next()
      }
    }
  })
}

exports.returnTapahtumaNimi = function (req, res, next) {
  console.log("Bing @ the returnTapahtumaNimi controller")
  connection.query('SELECT DISTINCT nimi FROM tapahtuma', (error, results) => {
    if (error) {
      next(error)  
    } else {
      let tapahtuma_nimi = {"tapahtuma_nimi": []}
      for (let i in results.rows) {
        tapahtuma_nimi.tapahtuma_nimi.push(results.rows[i].nimi)
        if (results.rows.length - i === 1) {
          req.tieto.push(tapahtuma_nimi)
          next()
        }
      }
      if (results.rows.length === 0) {
        next()
      }
    }
  })
}

exports.returnTapahtumaLuonne = function (req, res, next) {
  console.log("Bing @ the returnTapahtumaLuonne controller")
  connection.query('SELECT DISTINCT luonne FROM tapahtuma', (error, results) => {
    if (error) {
      next(error)  
    } else {
      let luonne = {"tapahtuma_luonne": []}
      for (let i in results.rows) {
        luonne.tapahtuma_luonne.push(results.rows[i].luonne)
        if (results.rows.length - i === 1) {
          req.tieto.push(luonne)
          next()
        }
      }
      if (results.rows.length === 0) {
        next()
      }
    }
  })
}

exports.returnVuosi = function (req, res, next) {
  console.log("Bing @ the returnVuosi controller")
  connection.query('SELECT DISTINCT vuosi FROM tapahtuma', (error, results) => {
    if (error) {
      next(error)  
    } else {
      let vuosi = {"vuosi": []}
      for (let i in results.rows) {
        vuosi.vuosi.push(results.rows[i].vuosi)
        if (results.rows.length - i === 1) {
          req.tieto.push(vuosi)
          res.status(200).json(req.tieto)
        }
      }
      if (results.rows.length === 0) {
        res.status(200).json(req.tieto)
      }
    }
  })
}
