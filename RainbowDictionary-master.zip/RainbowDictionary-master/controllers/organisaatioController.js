//haetaan tietokantayhteys config.js:stä
const connection = require('../config.js');

'use strict';

  exports.listOrganizations = async function (req, res, next) {
    console.log("Bing @ the listOrganizations controller")

    let result = await haeOrganisaatiot();
    console.log("response ready")
    res.status(200).json(result)
  }

  const haeOrganisaatiot = async () => {
    // Etsitään kaikki organisaatiot
    let organisaatiot = await new Promise((resolve, reject) => connection.query('SELECT * FROM organisaatio', (error, results) => {
      if (error) {
        reject(error)
      } else {
        resolve(results.rows);
      }
    }));
    console.log("query ready");

    let res = await haeTiedot(organisaatiot);
    console.log("kaikkiSanat done");
    return res;
  }

  const haeTiedot = async (organisaatiot) => {
    // palautettava objekti
    let palautus = {"organisaatiot": []};
    console.log("inside kaikkiSanat");

    for (let j = 0; j < organisaatiot.length; j++) {
      let org = organisaatiot[j];
      // Etsitään organisaation tapahtumat
      let tapahtumat = await new Promise((resolve, reject) => connection.query('SELECT * FROM tapahtuma WHERE organisaatio_id = $1',
      [org.id], (error, results) => {
        if (error) {
          reject(error)
        } else {
          let sanat = results.rows
          // Etsitään tapahtuman asiasanat
          let kysely = 'SELECT DISTINCT (kuvaus) FROM tapahtuma, asiasana, liittyy WHERE asiasana.id = asiasana_id AND tapahtuma.id = tapahtuma_id AND tapahtuma_id = $1'
          for (let i = 0; i < results.rows.length; i++) {
            let aSanat = []
            connection.query(kysely, [results.rows[i].id], (error, results) => {
              if (error) {
                return (error)
              } else {
                // Jos tapahtumalla ei ole asiasanoja, palautetaan tapahtumat
                if (results.rows.length === 0) {
                  resolve(sanat)
                }
                // Etsitään tapahtuman kaikki asiasanat
                for (let k = 0; k < results.rows.length; k++) {
                  aSanat.push(results.rows[k].kuvaus)
                  // Jos viimeinen kierros
                  if (results.rows.length - k === 1) {
                    // Lisataan tapahtumaan asiasanat
                    sanat[i].asiasana = aSanat
                    // Jos kaikki tapahtumat tarkistettu palautetaan tapahtumat
                    if (sanat.length - i === 1) {
                      resolve(sanat)
                    }
                  }
                }
              }
            })
          }
        }
      }))

      // Etsitään organisaation sijainti
      let kysely = 'SELECT maa, paikkakunta FROM sijainti, org_toimii, organisaatio WHERE organisaatio_id = $1 AND sijainti.id = sijainti_id AND organisaatio.id = organisaatio_id'
      let sijainti = await new Promise((resolve, reject) => connection.query(kysely, [org.id], (error, results) => {
        if (error) {
          reject(error)
        } else {
          resolve(results.rows)
        }
      }))

      // jos organisaatiolla on sijainti
      if (sijainti.length > 0) {
        // Lisataan organisaatioon maa
        org.maa = sijainti[0].maa
        // Lisataan organisaatioon paikkakunta
        org.paikkakunta = sijainti[0].paikkakunta
      }
      // Lisataan organisaatioon tapahtumat
      org.tapahtumat = tapahtumat

      // Lisätään organisaatio ja sen tapahtumat listaan muiden organisaatojen kanssa
      palautus.organisaatiot.push(org);
    }
    console.log("palautus")
    return (palautus)
  }

  exports.returnOrganization = function (req, res, next) {
    console.log("Bing @ the returnOrganization controller")
    const id = parseInt(req.params.id)
    connection.query('SELECT * FROM organisaatio WHERE id = $1', [id], (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Organization with given id does not exist!" });      
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  }

  exports.insertOrganization = function (req, res, next) {
    console.log("Bing @ the insertOrganization controller")
    const { org_nimi } = req.body

    if (org_nimi == null) {
      return res.status(500).json({ error: "organisaation nimi on null!" });
    }
    else {
      let kysely = 'INSERT INTO organisaatio (nimi) VALUES ($1) ON CONFLICT (nimi) DO UPDATE SET nimi=EXCLUDED.nimi RETURNING id'
      connection.query(kysely, [org_nimi], (error, results) => {
        if (error) {
          return next(error)
        } else {
          console.log("Added organization or it was already there!")
          req.orgId = results.rows[0].id
          next()
        }
      })
    }
  }

  exports.insertLocation = function (req, res, next) {
    console.log("Bing @ the insertLocation controller")
    const { maa, paikkakunta } = req.body

    if (maa != null) {
      let kysely = 'INSERT INTO sijainti (maa, paikkakunta) VALUES ($1, $2) ON CONFLICT (maa, paikkakunta) DO UPDATE SET maa=EXCLUDED.maa RETURNING id'
      connection.query(kysely, [maa, paikkakunta], (error, results) => {
        if (error) {
          return next(error)
        } else {
          console.log("Location added")
          connection.query('INSERT INTO org_toimii (organisaatio_id, sijainti_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [req.orgId, results.rows[0].id], (error, results) => {
            if (error) {
              return next(error)
            }
            else {
              next()
            }
          })
        }
      })
    }
    else {
      next()
    }
  }

  exports.insertEvent = function (req, res, next) {
    console.log("Bing @ the insertEvent controller")
    const { tapahtuma_nimi, luonne, vuosi } = req.body

    connection.query('INSERT INTO tapahtuma (nimi, vuosi, luonne, organisaatio_id) VALUES ($1, $2, $3, $4) RETURNING *',
    [tapahtuma_nimi, vuosi, luonne, req.orgId], (error, results) => {
      if (error) {
        return next(error)
      }
      else {
        req.tapahtuma_id = results.rows[0].id
        req.tapahtuma = results.rows[0]
        next()
      }
    })
  }

  exports.insertAsiasana = function (req, res, next) {
    console.log("Bing @ the insertAsiasana controller")
    const { kuvaus } = req.body

    if (kuvaus != null) {
      let kysely = 'INSERT INTO asiasana (kuvaus) VALUES ($1) ON CONFLICT (kuvaus) DO UPDATE SET kuvaus=EXCLUDED.kuvaus RETURNING id'
      connection.query(kysely, [kuvaus], (error, results) => {
        if (error) {
          return next(error)
        } else {
          console.log("Added word to asiasana or it was already there!")
          connection.query('INSERT INTO liittyy (asiasana_id, tapahtuma_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [results.rows[0].id, req.tapahtuma_id], (error, results) => {
            if (error) {
              return next(error)
            }
            else {
              res.status(201).json(req.tapahtuma)
            }
          })
        }
      })
    } else {
      console.log("Asiasana has no value!")
      res.status(201).json(req.tapahtuma)
    }
  }

  exports.deleteLocation = function (req, res, next) {
    console.log("Bing @ the deleteLocation controller")
    const id = parseInt(req.params.id)

    if (req.body.nimi == null) {
      return res.status(500).json({ error: "organisaation nimi on null!" });
    }

    connection.query('DELETE FROM org_toimii WHERE organisaatio_id = $1', [id], (error, results) => {
      if (error) {
        next(error)
      }
      else {
        next()
      }
    })
  }

  exports.addLocation = function (req, res, next) {
    console.log("Bing @ the addLocation controller")
    const id = parseInt(req.params.id)
    const { maa, paikkakunta } = req.body

    if (maa != null) {
      // Lisataan sijainti
      let sijaintiId = connection.query('INSERT INTO sijainti (maa, paikkakunta) VALUES ($1, $2) ON CONFLICT (maa, paikkakunta) DO UPDATE SET maa=EXCLUDED.maa RETURNING id',
      [maa, paikkakunta], (error, results) => {
        if (error) {
          next(error)
        } else {
          console.log("Added sijainti or it was already there!")
          sijaintiId = (results.rows[0].id);

          // Luodaan yhteys organisaation ja sijainnin valille
          connection.query('INSERT INTO org_toimii (organisaatio_id, sijainti_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [id, sijaintiId], (error, results) => {
            if (error) {
              next(error)
            }
            else {
              next()
            }
          })
        }
      });
    }
    else {
      next()
    }
  }

  exports.updateOrg = function (req, res, next) {
    console.log("Bing @ the updateOrg controller")
    const id = parseInt(req.params.id)
    const { nimi } = req.body

    connection.query('UPDATE organisaatio SET nimi = $1 WHERE id = $2 RETURNING *',
    [nimi, id], (error, results) => {
      if (error) {
        next(error)
       } else if (results.rows[0] == null) {
         res.status(404).json({ error: "Organization with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  }

  exports.deleteAsiasana = function (req, res, next) {
    console.log("Bing @ the deleteAsiasana controller")
    const id = parseInt(req.params.id)

    connection.query('DELETE FROM liittyy WHERE tapahtuma_id = $1', [id], (error, results) => {
      if (error) {
        next(error)
      }
      else {
        next()
      }
    })
  }

  exports.addAsiasana = function (req, res, next) {
    console.log("Bing @ the addAsiasana controller")
    const id = parseInt(req.params.id)
    const { kuvaus } = req.body

    if (kuvaus != null) {
      // Asiasanat erotetaan toisistaan
      let aSanat = kuvaus.split(";");
      for (let k = 0; k < aSanat.length; k++) {
        // Lisataan uudet asiasanat asiasana tauluun
        let asiasanaId = connection.query('INSERT INTO asiasana (kuvaus) VALUES ($1) ON CONFLICT (kuvaus) DO UPDATE SET kuvaus=EXCLUDED.kuvaus RETURNING id',
        [aSanat[k]], (error, results) => {
          if (error) {
            next(error)
          } else {
            console.log("Added word to asiasana or it was already there!")
            asiasanaId = (results.rows[0].id);

            // Luodaan yhteydet asiasanojen ja tapahtuman välille
            connection.query('INSERT INTO liittyy (asiasana_id, tapahtuma_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [asiasanaId, id], (error, results) => {
              if (error) {
                next(error)
              }
            })
          }
        });
      }
      next()
    }
    else {
      next()
    }
  }

  exports.updateEvent = function (req, res, next) {
    console.log("Bing @ the updateEvent controller")
    const id = parseInt(req.params.id)
    const { nimi, luonne, vuosi } = req.body

    connection.query('UPDATE tapahtuma SET nimi = $1, luonne = $2, vuosi = $3 WHERE id = $4 RETURNING *',
    [nimi, luonne, vuosi, id], (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Event with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  }

  exports.deleteOrganization = function (req, res, next) {
    console.log("Bing @ the deleteOrganization controller")
    const id = parseInt(req.params.id)

    connection.query('DELETE FROM organisaatio WHERE id = $1 RETURNING *', [id], (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Organization with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  }

  exports.deleteEvent = function (req, res, next) {
    console.log("Bing @ the deleteEvent controller")
    const id = parseInt(req.params.id)

    connection.query('DELETE FROM tapahtuma WHERE id = $1 RETURNING *', [id], (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Event with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  }
