//haetaan tietokantayhteys config.js:stä
const connection = require('../config.js');

'use strict';

  exports.listCulture = async function (req, res, next) {
    console.log("Bing @ the listCulture controller")
  
    let result = await haeHenkilot();
    console.log("response ready")
    res.status(200).json(result)
  }
  
  const haeHenkilot = async () => {
    // Etsitään kaikki henkilot
    let henkilot = await new Promise((resolve, reject) => connection.query('SELECT * FROM henkilo', (error, results) => {
      if (error) {
        reject(error)
      } else {
        resolve(results.rows);
      }
    }));
    console.log("query ready");
  
    let res = await haeTiedot(henkilot);
    console.log("kaikkiSanat done");
    return res;
  }  
  
  const haeTiedot = async (henkilot) => {
    // palautettava objekti
    let palautus = {"henkilot": []};
    console.log("inside kaikkiSanat");

    for (let j = 0; j < henkilot.length; j++) {
      let henkilo = henkilot[j];
      // Etsitään henkilon teokset
      let kysely3 = 'SELECT teos.id, teos.nimi, teos.lajityyppi FROM teos, tekee, henkilo WHERE henkilo_id = $1 AND henkilo.id = henkilo_id AND teos.id = teos_id'
      let teokset = await new Promise((resolve, reject) => connection.query(kysely3, [henkilo.id], (error, results) => {
        if (error) {
          reject(error)
        } else {
          let tuotteet = results.rows
          // Etsitään teoksen asiasanat
          let kysely = 'SELECT DISTINCT (kuvaus) FROM teos, asiasana, sisaltaa WHERE asiasana.id = asiasana_id AND teos.id = teos_id AND teos_id = $1'
          for (let i = 0; i < results.rows.length; i++) {
            let aSanat = []
            // Etsitaan teoksen sijainti
            connection.query('SELECT maa, paikkakunta FROM sijainti, tapahtuu_teos, teos WHERE sijainti.id = sijainti_id AND teos.id = teos_id AND teos.id = $1',
            [results.rows[i].id], (error, results2) => {
              if (results2.rows.length > 0) {
                console.log("sijainti added")
                // Lisataan teoksen sijainti teokseen
                tuotteet[i].teos_maa = results2.rows[0].maa
                tuotteet[i].teos_paikkakunta = results2.rows[0].paikkakunta
              }
              // Teoksen asiasanat
              connection.query(kysely, [results.rows[i].id], (error, results) => {
                if (error) {
                  return (error)
                } else {
                  // Jos ei asiasanoja palauta teokset
                  if (results.rows.length === 0) {
                    resolve(tuotteet)
                  } else {
                    // Lisää teokseen asiasanoja
                    for (let k = 0; k < results.rows.length; k++) {
                      aSanat.push(results.rows[k].kuvaus)
                      // Jos viimeinen kierros
                      if (results.rows.length - k === 1) {
                        // Lisataan teokseen asiasanojen lista
                        tuotteet[i].asiasana = aSanat
                        // Jos kaikki teokset tarkistettu palauta teokset
                        if (tuotteet.length - i === 1) {
                          resolve(tuotteet)
                        }
                      }
                    }
                  }
                }
              })
            })
          }
        }
      }))
  
      // Etsitään henkilon sijainti
      let kysely = 'SELECT maa, paikkakunta FROM sijainti, toimii_henkilo, henkilo WHERE henkilo_id = $1 AND sijainti.id = sijainti_id AND henkilo.id = henkilo_id'
      let sijainti = await new Promise((resolve, reject) => connection.query(kysely, [henkilo.id], (error, results) => {
        if (error) {
          reject(error)
        } else {
          resolve(results.rows)
        }
      }))

      // Etsitään henkilon ammatti
      let kysely2 = 'SELECT ammattinimike FROM ammatti, harjoittaa, henkilo WHERE henkilo_id = $1 AND ammatti.id = ammatti_id AND henkilo.id = henkilo_id'
      let ammatit = await new Promise((resolve, reject) => connection.query(kysely2, [henkilo.id], (error, results) => {
        if (error) {
          reject(error)
        } else {
          let ammattinimikkeet = []
          if (results.rows.length === 0) {
            resolve(ammattinimikkeet)
          } else {
            // Lisää teokseen asiasanoja
            for (let k = 0; k < results.rows.length; k++) {
              ammattinimikkeet.push(results.rows[k].ammattinimike)
              // Jos viimeinen kierros
              if (results.rows.length - k === 1) {
                // Lisataan teokseen asiasanojen lista
                resolve(ammattinimikkeet)
              }
            }
          }
        }
      }))

      // Lisataan henkilolle ammatti
      henkilo.ammatti = ammatit

      // jos henkilolla on sijainti
      if (sijainti.length > 0) {
        // Lisataan henkiloon maa
        henkilo.maa = sijainti[0].maa

        // Lisataan henkiloon paikkakunta
        henkilo.paikkakunta = sijainti[0].paikkakunta
      }
      // Lisataan organisaatioon tapahtumat
      henkilo.teokset = teokset

      // Lisätään organisaatio ja sen tapahtumat listaan muiden organisaatojen kanssa
      palautus.henkilot.push(henkilo);
    }
    console.log("palautus")
    return (palautus)
  }

  exports.returnCulture = function (req, res, next) {
    console.log("Bing @ the returnCulture controller")
  
    // Send status not found
    res.sendStatus(404);
  }

  exports.postCulture = async function (req, res, next) {
    console.log("Bing @ the postCulture controller")
    const { henkilo_maa, henkilo_paikkakunta, ammattinimike, teos_maa, teos_paikkakunta, nimi, lajityyppi, kuvaus} = req.body
    let { etunimi, sukunimi } = req.body

    if (nimi == null || lajityyppi == null) {
      return res.status(500).json({ error: "nimi tai lajityyppi on null!" });
    }

    if (etunimi == null || sukunimi == null) {
      etunimi = "anonyymi"
      sukunimi = "anonyymi"
    }
    // Lisataan henkilo
    let kysely = 'INSERT INTO henkilo (etunimi, sukunimi) VALUES ($1, $2) ON CONFLICT (etunimi, sukunimi) DO UPDATE SET etunimi=EXCLUDED.etunimi RETURNING id'
    let henkiloId = await new Promise((resolve, reject) => connection.query(kysely, [etunimi, sukunimi], (error, results) => {
      if (error) {
        return next(error)
      } else {
        console.log("Added organization or it was already there!")
        resolve(results.rows[0].id);
      }
    }));

    // Lisataan sijainti
    if (henkilo_maa != null) {
      let kysely = 'INSERT INTO sijainti (maa, paikkakunta) VALUES ($1, $2) ON CONFLICT (maa, paikkakunta) DO UPDATE SET maa=EXCLUDED.maa RETURNING id'
      let sijaintiId = connection.query(kysely, [henkilo_maa, henkilo_paikkakunta], (error, results) => {
        if (error) {
          return next(error)
        } else {
          sijaintiId = results.rows[0].id
          console.log("Location added or it already existed!")
          connection.query('INSERT INTO toimii_henkilo (sijainti_id, henkilo_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [sijaintiId, henkiloId], (error, results) => {
            if (error) {
              return next(error)
            }
          })
        }
      })
    }

    // Lisataan ammatti
    if (ammattinimike != null) {
      let kysely = 'INSERT INTO ammatti (ammattinimike) VALUES ($1) ON CONFLICT (ammattinimike) DO UPDATE SET ammattinimike=EXCLUDED.ammattinimike RETURNING id'
      let ammattiId = connection.query(kysely, [ammattinimike], (error, results) => {
        if (error) {
          return next(error)
        } else {
          ammattiId = results.rows[0].id
          console.log("Profession added")
          connection.query('INSERT INTO harjoittaa (henkilo_id, ammatti_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [henkiloId, ammattiId], (error, results) => {
            if (error) {
              return next(error)
            }
          })
        }
      })
    }

    // Lisataan teos
    let kysely2 = 'INSERT INTO teos (nimi, lajityyppi) VALUES ($1, $2) ON CONFLICT (nimi, lajityyppi) DO UPDATE SET nimi=EXCLUDED.nimi RETURNING *'
    let teosId = connection.query(kysely2, [nimi, lajityyppi], (error, results) => {
      if (error) {
        return next(error)
      } else {
        teosId = results.rows[0].id
        console.log("Work added")
        connection.query('INSERT INTO tekee (henkilo_id, teos_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
        [henkiloId, teosId], (error, results) => {
          if (error) {
            return next(error)
          }
        })
      }

      // Lisataan sijainti teokselle
      if (teos_maa != null) {
        let kysely = 'INSERT INTO sijainti (maa, paikkakunta) VALUES ($1, $2) ON CONFLICT (maa, paikkakunta) DO UPDATE SET maa=EXCLUDED.maa RETURNING id'
        connection.query(kysely, [teos_maa, teos_paikkakunta], (error, results) => {
          if (error) {
            return next(error)
          } else {
            console.log("Location added or it already existed!")
            connection.query('INSERT INTO tapahtuu_teos (sijainti_id, teos_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [results.rows[0].id, teosId], (error, results) => {
              if (error) {
                return next(error)
              }
            })
          }
        });
      }
      else {
        console.log("Teos has no location!")
      }

      // Jos asiasana annetaan, se lisataan tietokantaan.
      if (kuvaus != null) {
        let kysely = 'INSERT INTO asiasana (kuvaus) VALUES ($1) ON CONFLICT (kuvaus) DO UPDATE SET kuvaus=EXCLUDED.kuvaus RETURNING id'
        connection.query(kysely, [kuvaus], (error, results) => {
          if (error) {
            return next(error)
          } else {
            console.log("Added word to asiasana or it was already there!")
            connection.query('INSERT INTO sisaltaa (asiasana_id, teos_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [results.rows[0].id, teosId], (error, results) => {
              if (error) {
                return next(error)
              }
            })
          }
        });
      }
      else {
        console.log("Asiasana has no value!")
      }
      res.status(201).json(results.rows[0])
    })
  }

  exports.updateCulture = function (req, res, next) {
    console.log("Bing @ the updateCulture controller")
    const id = parseInt(req.params.id)
    const { nimi, lajityyppi, teos_maa, teos_paikkakunta, kuvaus } = req.body
  
    // Poistetaan yhteydet asiasanojen ja teoksen valilla
    connection.query('DELETE FROM sisaltaa WHERE teos_id = $1', [id], (error, results) => {
      if (error) {
        next(error)
      } else {
        // Jos annetaan asiasanoja
        if (kuvaus != null) {
          // Asiasanat erotetaan toisistaan
          let aSanat = kuvaus.split(";");
          for (let k = 0; k < aSanat.length; k++) {
            // Lisataan uudet asiasanat asiasana tauluun
            let asiasanaId = connection.query('INSERT INTO asiasana (kuvaus) VALUES ($1) ON CONFLICT (kuvaus) DO UPDATE SET kuvaus=EXCLUDED.kuvaus RETURNING id',
            [aSanat[k]], (error, results) => {
              if (error) {
                next(error)
              } else {
                console.log("Added word to asiasana or it was already there!")
                asiasanaId = (results.rows[0].id);
  
                // Luodaan yhteydet asiasanojen ja teoksen välille
                connection.query('INSERT INTO sisaltaa (asiasana_id, teos_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
                [asiasanaId, id], (error, results) => {
                  if (error) {
                    next(error)
                  }
                })
              }
            });
          }
        }
      }
    })

    // Poistetaan yhteys teoksen ja sen sijainnin valilla
    connection.query('DELETE FROM tapahtuu_teos WHERE teos_id = $1', [id], (error, results) => {
      if (error) {
        next(error)
      } else {
        // Jos annetaan sijainti
        if (teos_maa != null) {
          let sijaintiId = connection.query('INSERT INTO sijainti (maa, paikkakunta) VALUES ($1, $2) ON CONFLICT (maa, paikkakunta) DO UPDATE SET maa=EXCLUDED.maa RETURNING id',
          [teos_maa, teos_paikkakunta], (error, results) => {
            if (error) {
              next(error)
            } else {
              console.log("Added sijainti or it was already there!")
              sijaintiId = (results.rows[0].id);

              // Luodaan yhteys teoksen ja sijainnin valille
              connection.query('INSERT INTO tapahtuu_teos (sijainti_id, teos_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
              [sijaintiId, id], (error, results) => {
                if (error) {
                  next(error)
                }
              })
            }
          });
        }
      }
    })

    connection.query(
      'UPDATE teos SET nimi = $1, lajityyppi = $2 WHERE id = $3 RETURNING *',
      [nimi, lajityyppi, id],
      (error, results) => {
        if (error) {
          next(error)
        } else if (results.rows[0] == null) {
          res.status(404).json({ error: "Teos with given id does not exist!" });
        } else {
          res.status(200).json(results.rows[0])
        }
      }
    )
  }

  exports.updatePerson = function (req, res, next) {
    console.log("Bing @ the updatePerson controller")
    const id = parseInt(req.params.id)
    const { ammattinimike, henkilo_maa, henkilo_paikkakunta } = req.body
    let { etunimi, sukunimi } = req.body

    if (etunimi == null || sukunimi == null) {
      res.status(500).json({ error: "Give first name and last name!" });
    }
    // Paivitetaan henkilo
    connection.query('UPDATE henkilo SET etunimi = $1, sukunimi = $2 WHERE id = $3 RETURNING *',
    [etunimi, sukunimi, id], (error, results) => {
      if (error) {
        res.status(500).json({ error: "Person already exists! Give another name!" });
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Person with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  
    // Poistetaan yhteydet henkilon ja ammatin valilla
    connection.query('DELETE FROM harjoittaa WHERE henkilo_id = $1', [id], (error, results) => {
      // Jos annetaan ammatteja
      if (ammattinimike != null) {
        // Ammatit erotetaan toisistaan
        let ammatit = ammattinimike.split(";");
        for (let k = 0; k < ammatit.length; k++) {
          // Lisataan uudet ammatit ammatti tauluun
          let ammattiId = connection.query('INSERT INTO ammatti (ammattinimike) VALUES ($1) ON CONFLICT (ammattinimike) DO UPDATE SET ammattinimike=EXCLUDED.ammattinimike RETURNING id',
          [ammatit[k]], (error, results) => {
            console.log("Added ammatti or it was already there!")
            ammattiId = (results.rows[0].id);

            // Luodaan yhteydet ammattien ja henkilon valille
            connection.query('INSERT INTO harjoittaa (henkilo_id, ammatti_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [id, ammattiId], (error, results) => {
            })
          })
        }
      }
    })


    // Poistetaan yhteys henkilon ja sijainnin valilla
    connection.query('DELETE FROM toimii_henkilo WHERE henkilo_id = $1', [id], (error, results) => {
      // Jos annetaan sijainti
      if (henkilo_maa != null) {
        let sijaintiId = connection.query('INSERT INTO sijainti (maa, paikkakunta) VALUES ($1, $2) ON CONFLICT (maa, paikkakunta) DO UPDATE SET maa=EXCLUDED.maa RETURNING id',
        [henkilo_maa, henkilo_paikkakunta], (error, results) => {
          console.log("Added sijainti or it was already there!")
          sijaintiId = (results.rows[0].id);

          // Luodaan yhteys henkilon ja sijainnin valille
          connection.query('INSERT INTO toimii_henkilo (henkilo_id, sijainti_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [id, sijaintiId], (error, results) => {
          })
        });
      }
    })
  }

  exports.deleteCulture = function (req, res, next) {
    console.log("Bing @ the deleteCulture controller")
    const id = parseInt(req.params.id)

    connection.query('DELETE FROM teos WHERE id = $1 RETURNING *', [id], (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Work with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  }

  exports.deletePerson = function (req, res, next) {
    console.log("Bing @ the deletePerson controller")
    const id = parseInt(req.params.id)

    connection.query('DELETE FROM henkilo WHERE id = $1 RETURNING *', [id], (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Person with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  }