//haetaan tietokantayhteys config.js:stä
const connection = require('../config.js');

'use strict';

// Hakee kaikki tietokannan sanat
exports.listWords = async function (req, res, next) {
  console.log("Bing @ the listWords controller")

  let result = await hakusanat();
  console.log("response ready")
  console.log(result)
  res.status(200).json(result)
}

const hakusanat = async () => {
  // Etsitään kaikki hakusanat
  let hakusanat = await new Promise((resolve, reject) => connection.query('SELECT * FROM hakusana', (error, results) => {
    if (error) {
      reject(error)
    } else {
      resolve(results.rows);
    }
  }));
  console.log("query ready");
  console.log(hakusanat)

  let res = await kaikkiSanat(hakusanat);
  console.log("kaikkiSanat done");
  return res;
}  

const kaikkiSanat = async (hakusanat) => {
  // palautettava objekti
  let palautus = {"sanat": []};
  console.log("inside kaikkiSanat");

  for (let j = 0; j < hakusanat.length; j++) {
    let hakuSana = hakusanat[j];
    // Etsitään sanan kaikki ilmentymät
    let sanaIlmentymat = await new Promise((resolve, reject) => connection.query('SELECT * FROM ilmentyma WHERE sana_id = $1',
    [hakuSana.id], (error, results) => {
      if (error) {
        reject(error)
      } else {
        resolve(results.rows);
      }
    }));

    // Etsitään hakusanaan liittyvät asiasanat
    let kysely = 'SELECT DISTINCT (kuvaus) FROM ilmentyma, asiasana, edustaa WHERE asiasana.id = asiasana_id AND ilmentyma.id = ilmentyma_id AND sana_id = $1'
    let asiasanat = await new Promise((resolve, reject) => connection.query(kysely, [hakuSana.id], (error,results) => {
      if (error) {
        reject(error)
      } else {
        let aSanat = [];
        for (let k = 0; k < results.rows.length; k++) {
          aSanat.push(results.rows[k].kuvaus)
          console.log("Asiasana pushed!")
        }
        resolve(aSanat)
      }
    }))

    // Etsitään aikaisin ilmentymä hakusanalle.
    let aikaisin = await new Promise((resolve, reject) => connection.query('SELECT MIN (paivays) FROM ilmentyma where sana_id = $1',
    [hakuSana.id], (error, results) => {
      let pv = null
      if (error) {
        reject(error)
      } else if (results.rows[0].min != null) {
        pv = results.rows[0].min
        pv.setDate(pv.getDate() +1);
        pv = pv.toISOString()
        pv = pv.substring(0,10)
        console.log(pv)
      }
      resolve(pv)
    }));

    // Etsitään viimeisin ilmentyma hakusanalle.
    let viimeisin = await new Promise((resolve, reject) => connection.query('SELECT MAX (paivays) FROM ilmentyma where sana_id = $1',
    [hakuSana.id], (error, results) => {
      let pv = null
      if (error) {
        reject(error)
      } else if (results.rows[0].max != null) {
        pv = results.rows[0].max
        pv.setDate(pv.getDate() +1);
        pv = pv.toISOString()
        pv = pv.substring(0,10)
        console.log(pv)
      }
      resolve(pv)
    }));

    // Lisätään sanaan asiasanat
    hakuSana.asiasanat = asiasanat
    // Lisätään sanaan aikaisin
    hakuSana.aikaisin = aikaisin
    // Lisätään sanaan viimeisin
    hakuSana.viimeisin = viimeisin
    // Lisätään sanaan ilmentymät
    hakuSana.ilmentymat = sanaIlmentymat
    // Yksi asiasana ja sen ilmeytymät
    console.log(hakuSana)
    // Lisätään asiasana ja sen ilmeytymät listaan muiden asiasanojen kanssa
    palautus.sanat.push(hakuSana);
  }
  console.log("palautus")
  return (palautus)
}

// Hakee id:n perusteella tietokannasta yhden sanan
exports.returnWord = function (req, res, next) {
  console.log("Bing @ the returnWord controller")
  const id = parseInt(req.params.id)
  connection.query('SELECT * FROM hakusana WHERE id = $1', [id], (error, results) => {
    if (error) {
      next(error)
    } else if (results.rows[0] == null) {
      res.status(404).json({ error: "Word with given id does not exist!" });      
    } else {
      res.status(200).json(results.rows[0])
    }
  })
}

exports.listChoices = function (req, res, next) {
  console.log("Bing @ the listChoices controller")

  // Send status not found
  res.sendStatus(404);
}

exports.returnWordclass =  function (req, res, next) {
  console.log("Bing @ the returnWordclass controller")
  
  // Send status not found
  res.sendStatus(404);
}

// Lisaa sanan tietokantaan.
exports.postWord = async function (req, res, next) {
  console.log("Bing @ the postWord controller")
  const { sana, sanaluokka, hs_osio, paivays, selite, tyyli, kayttoala, lause, kuvaus } = req.body

  if (sana == null) {
    return res.status(500).json({ error: "sana on null!" });
  }

  let pvm
  if (paivays != null) {
    let pv = paivays.substring(2, 10)
    // date YYYY-MM-DD
    pvm = pv.substring(0, 4) + "-" + pv.substring(4, 6) + "-" + pv.substring(6, 8)
    console.log(pvm)
  }

  // Lisataan sana hakusana tauluun, jos sita ei viela ole.
  let kysely = 'INSERT INTO hakusana (sana, sanaluokka) VALUES ($1, $2) ON CONFLICT (sana, sanaluokka) DO UPDATE SET sana=EXCLUDED.sana RETURNING id'
  let sanaId = await new Promise((resolve, reject) => connection.query(kysely, [sana, sanaluokka], (error, results) => {
    if (error) {
      next(error)
    } else {
      console.log("Added word to hakusana or it was already there!")
      resolve(results.rows[0].id);
    }
  }));

  // Lisataan ilmentyma
  let ilm_id = connection.query('INSERT INTO ilmentyma (sana_id, lause, sivunumero, paivays, hs_osio, tyyli, kayttoala, selite) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *',
  [sanaId, lause, paivays, pvm, hs_osio, tyyli, kayttoala, selite], (error, results) => {
    if (error) {
      return next(error)
    }
    // Jos asiasana annetaan, se lisataan tietokantaan.
    else if (kuvaus != null) {
      ilm_id = results.rows[0].id
      let kysely = 'INSERT INTO asiasana (kuvaus) VALUES ($1) ON CONFLICT (kuvaus) DO UPDATE SET kuvaus=EXCLUDED.kuvaus RETURNING id'
      connection.query(kysely, [kuvaus], (error, results) => {
        if (error) {
          next(error)
        } else {
          console.log("Added word to asiasana or it was already there!")
          connection.query('INSERT INTO edustaa (asiasana_id, ilmentyma_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
          [results.rows[0].id, ilm_id], (error, results) => {
            if (error) {
              return next(error)
            }
          })
        }
      });
    } else {
      console.log("Asiasana has no value!")
    }
    res.status(201).json(results.rows[0])
  })
}

// Muuttaa ilmentymaa
exports.updateOccurence = function (req, res, next) {
  console.log("Bing @ the updateOccurence controller")
  const id = parseInt(req.params.id)
  const { hs_osio, paivays, selite, tyyli, kayttoala, lause, kuvaus } = req.body

  connection.query('DELETE FROM edustaa WHERE ilmentyma_id = $1', [id], (error, results) => {
    console.log("eka")
    if (error) {
      next(error)
    } else {
      // Jos annetaan asiasanoja
      if (kuvaus != null) {
        // Asiasanat erotetaan toisistaan
        let aSanat = kuvaus.split(";");
        for (let k = 0; k < aSanat.length; k++) {
          // Lisataan uudet asiasanat asiasana tauluun
          let asiasanaId = connection.query('INSERT INTO asiasana (kuvaus) VALUES ($1) ON CONFLICT (kuvaus) DO UPDATE SET kuvaus=EXCLUDED.kuvaus RETURNING id',
          [aSanat[k]], (error, results) => {
            if (error) {
              next(error)
            } else {
              console.log("toka")
              console.log("Added word to asiasana or it was already there!")
              asiasanaId = (results.rows[0].id);

              // Luodaan yhteydet asiasanojen ja ilmentyman välille
              connection.query('INSERT INTO edustaa (asiasana_id, ilmentyma_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
              [asiasanaId, id], (error, results) => {
                console.log("kolmas")
                if (error) {
                  next(error)
                }
              })
            }
          });
        }
      }
    }
  })

  let pv = paivays.substring(2, 10)
  // date YYYY-MM-DD
  let pvm = pv.substring(0, 4) + "-" + pv.substring(4, 6) + "-" + pv.substring(6, 8)

  connection.query(
    'UPDATE ilmentyma SET hs_osio = $1, paivays = $2, sivunumero = $3, selite = $4, tyyli = $5, kayttoala = $6, lause = $7 WHERE id = $8 RETURNING *',
    [hs_osio, pvm, paivays, selite, tyyli, kayttoala, lause, id],
    (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Occurence with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
}

// Muutetaan hakusanaa
exports.updateWord = function (req, res, next) {
  console.log("Bing @ the updateWord controller")
  const id = parseInt(req.params.id)
  const { sana, sanaluokka } = req.body

  if (sana != null) {
    // Muokataan hakusanan sanaa ja sanaluokkaa
    connection.query('UPDATE hakusana SET sana = $1, sanaluokka = $2 WHERE id = $3 RETURNING *',
    [sana, sanaluokka, id], (error, results) => {
      if (error) {
        next(error)
      } else if (results.rows[0] == null) {
        res.status(404).json({ error: "Word with given id does not exist!" });
      } else {
        res.status(200).json(results.rows[0])
      }
    })
  } else {
    res.status(400).json({ error: "Sana needs a value!" });
  }
}

// Poistaa ilmentyman
exports.deleteOccurence = function (req, res, next) {
  console.log("Bing @ the deleteOccurence controller")
  const id = parseInt(req.params.id)

  // Poistaa ilmentyman yhteyden asiasanaan
  connection.query('DELETE FROM edustaa WHERE ilmentyma_id = $1', [id], (error, results) => {
    if (error) {
      next(error)
    } else {
      // Poistaa ilmentyman
      connection.query('DELETE FROM ilmentyma WHERE id = $1 RETURNING *', [id], (error, results) => {
        if (error) {
          next(error)
        } else if (results.rows[0] == null) {
          res.status(404).json({ error: "Occurence with given id does not exist!" });
        } else {
          res.status(200).json(results.rows[0])
        }
      })
    }
  })
}

// Poistaa hakusanan ja sen ilmentymat
exports.deleteWord = function (req, res, next) {
  console.log("Bing @ the deleteWord controller")
  const id = parseInt(req.params.id)

  // Poistaa hakusanan ilmentymat
  connection.query('DELETE FROM ilmentyma WHERE sana_id = $1', [id], (error, results) => {
    if (error) {
      next(error)
    }
    else {
      // Poistaa hakusanan
      connection.query('DELETE FROM hakusana WHERE id = $1 RETURNING *', [id], (error, results) => {
        if (error) {
          next(error)
        } else if (results.rows[0] == null) {
          res.status(404).json({ error: "Word with given id does not exist!" });
        } else {
          res.status(200).json(results.rows[0])
        }
      })
    }
  })
}