'use strict';
const express = require('express');
const api = express.Router();
const asiasanaController = require('../controllers/asiasanaController');
const organisaatioController = require('../controllers/organisaatioController');
const kulttuuriteosController = require('../controllers/kulttuuriteosController');
const kLomakeController = require('../controllers/kulttuuriteosLomakeController.js');
const sLomakeController = require('../controllers/sanalomakeController.js');
const oLomakeController = require('../controllers/organisaatiolomakeController.js');
const lomakeController = require('../controllers/lomakeController.js');

// TODO: CRUD-operaatiot sanoille
api.get('/api/hakusana', asiasanaController.listWords);

api.post('/api/hakusana', asiasanaController.postWord);

api.get('/api/hakusana/:id', asiasanaController.returnWord);

api.put('/api/hakusana/:id', asiasanaController.updateWord);

api.delete('/api/hakusana/:id', asiasanaController.deleteWord);

api.put('/api/ilmentyma/:id', asiasanaController.updateOccurence);

api.delete('/api/ilmentyma/:id', asiasanaController.deleteOccurence);

api.get('/api/choices', asiasanaController.listChoices);

api.get('/api/wordclass/:id', asiasanaController.returnWordclass);


api.get('/api/organisaatio', organisaatioController.listOrganizations);

api.post('/api/organisaatio',
  organisaatioController.insertOrganization,
  organisaatioController.insertLocation,
  organisaatioController.insertEvent,
  organisaatioController.insertAsiasana);

api.get('/api/organisaatio/:id', organisaatioController.returnOrganization);

api.put('/api/organisaatio/:id',
  organisaatioController.deleteLocation,
  organisaatioController.addLocation,
  organisaatioController.updateOrg);

api.delete('/api/organisaatio/:id', organisaatioController.deleteOrganization);

api.put('/api/tapahtuma/:id',
  organisaatioController.deleteAsiasana,
  organisaatioController.addAsiasana,
  organisaatioController.updateEvent);

api.delete('/api/tapahtuma/:id', organisaatioController.deleteEvent);


api.get('/api/kulttuuriteos', kulttuuriteosController.listCulture);

api.post('/api/kulttuuriteos', kulttuuriteosController.postCulture);

api.get('/api/kulttuuriteos/:id', kulttuuriteosController.returnCulture);

api.put('/api/kulttuuriteos/:id', kulttuuriteosController.updateCulture);

api.delete('/api/kulttuuriteos/:id', kulttuuriteosController.deleteCulture);

api.put('/api/henkilo/:id', kulttuuriteosController.updatePerson);

api.delete('/api/henkilo/:id', kulttuuriteosController.deletePerson);


api.get('/api/sanalomake',
  sLomakeController.returnPaivays,
  sLomakeController.returnHS_osio,
  sLomakeController.returnHakusana,
  sLomakeController.returnSelite,
  lomakeController.returnAsiasana,
  sLomakeController.returnSanaluokka,
  sLomakeController.returnTyyli,
  sLomakeController.returnKayttoala,
  sLomakeController.returnLause);

api.get('/api/kulttuuriteoslomake',
  kLomakeController.returnEtunimi,
  kLomakeController.returnSukunimi,
  kLomakeController.returnAmmatti,
  lomakeController.returnAsiasana,
  lomakeController.returnPaikkakunta,
  lomakeController.returnMaa,
  kLomakeController.returnTeosNimi,
  kLomakeController.returnLajityyppi);

api.get('/api/organisaatiolomake',
  oLomakeController.returnOrgNimi,
  lomakeController.returnAsiasana,
  oLomakeController.returnTapahtumaNimi,
  oLomakeController.returnTapahtumaLuonne,
  lomakeController.returnPaikkakunta,
  lomakeController.returnMaa,
  oLomakeController.returnVuosi);

module.exports = api;
