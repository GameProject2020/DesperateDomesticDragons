# RainbowDictionary

## Sovelluksen lokaali käynnistys
- Kun olet ladannut masterin, avaa terminaali juurikansioon
- Mikäli dependencyihin on tullut muutoksia:
- Anna komento "npm install"
- Mene kansioon "client"
- Anna komento "npm install"
- Mene juurikansioon ja anna komento "nodemon" (Nodemon pitää olla asennettuna koneelle, jotta tämä toimii!)
- Avaa toinen terminaali kansioon "client"
- Anna komento "npm start"

- Käynnistetyn lokaalin version saa sammutettua antamalla komennon "ctl + c" kummassakin terminaalissa
